//package com.example.hotel.service;
//
//import java.util.List;
//
//
//import com.example.hotel.payload.CustomerDTO;
//
//public interface CustomerService {
//	//add all user
// public CustomerDTO addCustomer(CustomerDTO customerDTO);
// //get all user
// public List<CustomerDTO> getAllcustomer();
// //get user by id
// public CustomerDTO getCustomerById(int customerId);
// //update user by id
// public CustomerDTO updateCustomerById(CustomerDTO customerDTO,int customerId);
// //delete user by id
// public void deleteCustomerById(int customerId);
//}
