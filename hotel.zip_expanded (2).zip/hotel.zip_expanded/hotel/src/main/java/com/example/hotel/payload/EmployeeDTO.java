package com.example.hotel.payload;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
//@Getter
//@Setter
@ToString
@NoArgsConstructor
public class EmployeeDTO {

	
	private int employeeId;
	
	
	private String empName;
	

	private String phoneNo;
	
	
	private String address;
}
