package com.example.hotel.exception;



import org.springframework.http.HttpStatusCode;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
public class APIResponse {
	private String message;
	  private boolean status;

	  public APIResponse(String message, boolean status) {
		super();
		this.message = message;
		this.status = status;
	}

	
}
