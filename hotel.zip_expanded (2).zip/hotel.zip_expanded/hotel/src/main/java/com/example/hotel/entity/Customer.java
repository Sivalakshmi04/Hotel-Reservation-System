//package com.example.hotel.entity;
//
//
//
//
//
//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//
//import jakarta.persistence.Table;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//import lombok.ToString;
//
//@Entity
////@Data
//@Getter
//@Setter
//@ToString
//@NoArgsConstructor
//@Table(name="customer_tbl")
//public class Customer {
//	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
//	private int customerId;
//	
//	@Column(length=30,nullable=false)
//   private String customerName;
//	
//	@Column(length=30,nullable=false)
//	   private String contactNumber;
//	
//	@Column(length=30,nullable=false,unique = true)
//   private String emailId;
//	
//	
////	@ManyToMany 
////	@JoinTable(name = "user_room",
////	joinColumns = @JoinColumn(name = "user_Id"),
////	inverseJoinColumns = @JoinColumn(name = "room_Id")
////	)
////	private Set<Room> roombooking=new HashSet<>();
////	
////	
////	@OneToMany(cascade = CascadeType.ALL)
////	@JoinColumn(name = "uId" , nullable=true , referencedColumnName = "userId")
////	@JsonManagedReference
////    private List<Payment> payments;
//	
//}
//
//
//
//
//
////@OneToMany(targetEntity = Payment.class,cascade = CascadeType.ALL)
//// @JoinColumn(name= "user_payment",referencedColumnName = "userId")
//// private List<Payment> payments;