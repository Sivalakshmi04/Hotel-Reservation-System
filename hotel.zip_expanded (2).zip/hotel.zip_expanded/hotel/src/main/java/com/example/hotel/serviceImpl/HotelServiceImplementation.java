package com.example.hotel.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hotel.entity.Hotel;

import com.example.hotel.exception.ResourceNotFoundException;
import com.example.hotel.payload.HotelDTO;
import com.example.hotel.repository.HotelRepository;
import com.example.hotel.service.HotelService;


@Service
public class HotelServiceImplementation  implements HotelService {

	 @Autowired 
		private HotelRepository repository;
	    
	    @Autowired 
	    private ModelMapper modelMapper;
	    
	@Override
	public HotelDTO addHotel(HotelDTO hotelDTO) {
		//StudentEntity studentEntity = studentDtoToStudentEntity(studentDTO);
				Hotel hotel = this.modelMapper.map(hotelDTO, Hotel.class);
				
				Hotel savedHotel = this.repository.save(hotel);
				return this.modelMapper.map(savedHotel, HotelDTO.class);
				//return studentEntityToStudentDto(savedStudent);
	}

	@Override
	public List<HotelDTO> getAllhotel() {

		List<Hotel> hotelList = this.repository.findAll();
		List<HotelDTO> hotelDtoList = hotelList.stream().map(hotelObj->this.modelMapper.map(hotelObj,HotelDTO.class)).collect(Collectors.toList());
		return hotelDtoList;
	}

	@Override
	public HotelDTO getHotelById(int hotelId) {
		{
			if(repository.existsById(hotelId)) {
				
			
		Hotel hotelObj=this.repository.findById(hotelId).get();
			return this.modelMapper.map(hotelObj, HotelDTO.class);
		}
			else 
			{
				throw  new ResourceNotFoundException("Hotel","Hotel Id",hotelId);
				
			}
	}
	}

	@Override
	public HotelDTO updateHotelById(HotelDTO hotelDTO, int hotelId) {
		
Hotel hotel=this.modelMapper.map(hotelDTO,Hotel.class);
		
		if(repository.existsById(hotelId))
	{
		Hotel updatedHotel=this.repository.save(hotel);
		return this.modelMapper.map(updatedHotel, HotelDTO.class);
	}
		else 
		{
			
			throw  new ResourceNotFoundException("Hotel","Hotel Id",hotelId);
		}
	}

	@Override
	public void deleteHotelById(int hotelId) {
		if(repository.existsById(hotelId))
		{
			repository.deleteById(hotelId);
		
	    }
		else
		{
			throw  new ResourceNotFoundException("Hotel","Hotel Id",hotelId);
		}
		
		
	}

}
