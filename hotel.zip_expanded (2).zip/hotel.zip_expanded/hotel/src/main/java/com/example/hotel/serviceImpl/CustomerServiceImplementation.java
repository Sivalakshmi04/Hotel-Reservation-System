//package com.example.hotel.serviceImpl;
//
//
//
//import java.util.List;
//import java.util.stream.Collectors;
//
//import org.modelmapper.ModelMapper;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.example.hotel.exception.*;
//
//import com.example.hotel.entity.Customer;
//import com.example.hotel.payload.CustomerDTO;
//import com.example.hotel.repository.CustomerRepository;
//import com.example.hotel.service.CustomerService;
//
//
//
//@Service
//public class CustomerServiceImplementation implements CustomerService{
//	 @Autowired 
//		private CustomerRepository repository;
//	    
//	    @Autowired 
//	    private ModelMapper modelMapper;
//	   
//	@Override
//	public CustomerDTO addCustomer(CustomerDTO customerDTO) {
//		//StudentEntity studentEntity = studentDtoToStudentEntity(studentDTO);
//		Customer customer = this.modelMapper.map(customerDTO, Customer.class);
//		
//		Customer savedCustomer = this.repository.save(customer);
//		return this.modelMapper.map(savedCustomer, CustomerDTO.class);
//		//return studentEntityToStudentDto(savedStudent);
//	}
//
//	@Override
//	public List<CustomerDTO> getAllcustomer() {
//		
//		List<Customer> customerList = this.repository.findAll();
//		List<CustomerDTO> customerDtoList = customerList.stream().map(customerObj->this.modelMapper.map(customerObj,CustomerDTO.class)).collect(Collectors.toList());
//		return customerDtoList;
//	}
//
//	@Override
//	public CustomerDTO getCustomerById(int customerId) {
//		{
//			if(repository.existsById(customerId)) {
//				
//			
//		Customer customerObj=this.repository.findById(customerId).get();
//			return this.modelMapper.map(customerObj, CustomerDTO.class);
//		}
//			else 
//			{
//				throw  new ResourceNotFoundException("Customer","Customer Id",customerId);
//				
//			}
//	}
//
//
//	}
//
//	@Override
//	public CustomerDTO updateCustomerById(CustomerDTO customerDTO, int customerId) {
//		Customer customer=this.modelMapper.map(customerDTO,Customer.class);
//		
//		if(repository.existsById(customerId))
//	{
//		Customer updatedCustomer=this.repository.save(customer);
//		return this.modelMapper.map(updatedCustomer, CustomerDTO.class);
//	}
//		else 
//		{
//			
//			throw  new ResourceNotFoundException("Customer","Customer Id",customerId);
//		}
//	}
//
//	@Override
//	public void deleteCustomerById(int customerId) {
//		if(repository.existsById(customerId))
//		{
//			repository.deleteById(customerId);
//		
//	    }
//		else
//		{
//			throw  new ResourceNotFoundException("Customer","Customerr Id",customerId);
//		}
//		
//	}
//
//	}
//
//	
//	
//
//	
//	
//	
//
