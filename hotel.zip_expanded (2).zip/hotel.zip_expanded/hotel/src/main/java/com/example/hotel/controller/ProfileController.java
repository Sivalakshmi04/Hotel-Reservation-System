package com.example.hotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.hotel.exception.APIResponse;
import com.example.hotel.payload.ProfileDTO;
import com.example.hotel.service.ProfileService;
@CrossOrigin("*")
@RestController
@RequestMapping("/customer")
public class ProfileController {


@Autowired
	private ProfileService customerService;
	
	@PostMapping("/save")
     public ResponseEntity<ProfileDTO> saveCustomer(@RequestBody ProfileDTO customerDTO)
     {
		ProfileDTO savedCustomer=this.customerService.addCustomer(customerDTO);
   	 System.out.println("********"+savedCustomer);
    	 return new ResponseEntity<ProfileDTO>(savedCustomer,HttpStatus.CREATED);
     }
@GetMapping("/")
public ResponseEntity<List<ProfileDTO>> getAllCustomers()
{
List<ProfileDTO> customerList	= this.customerService.getAllcustomer(); 
return new ResponseEntity<List<ProfileDTO>>(customerList,HttpStatus.OK);
}
@GetMapping("/{customerId}")
public ResponseEntity<ProfileDTO> getCustomerById(@PathVariable("customerId") int customerId)
{
	ProfileDTO customerObj=this.customerService.getCustomerById(customerId);
return new ResponseEntity<ProfileDTO>(customerObj,HttpStatus.OK);
}
@PutMapping("/{customerId}")
public ResponseEntity<ProfileDTO> updateUser(@RequestBody ProfileDTO  customerDTO,@PathVariable("customerId") int customerId)
{
	ProfileDTO updatedCustomer=this.customerService.updateCustomerById(customerDTO,customerId);
return new ResponseEntity<ProfileDTO>(updatedCustomer,HttpStatus.OK);
}
@DeleteMapping("/{customerId}")
public ResponseEntity<APIResponse> deleteCustomerById(@PathVariable("customerId") int customerId)
{
this.customerService.deleteCustomerById(customerId);
APIResponse obj=new APIResponse();
obj.setMessage("customer record is deleted successfully with Id "+customerId);
obj.setStatus(true);
return new ResponseEntity<APIResponse>(obj,HttpStatus.OK);
}
}