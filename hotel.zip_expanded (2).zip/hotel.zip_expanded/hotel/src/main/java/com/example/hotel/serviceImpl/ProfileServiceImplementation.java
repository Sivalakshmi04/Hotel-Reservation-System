package com.example.hotel.serviceImpl;



import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hotel.exception.*;

import com.example.hotel.entity.Profile;
import com.example.hotel.payload.ProfileDTO;
import com.example.hotel.repository.ProfileRepository;
import com.example.hotel.service.ProfileService;



@Service
public class ProfileServiceImplementation implements ProfileService{
	 @Autowired 
		private ProfileRepository repository;
	    
	    @Autowired 
	    private ModelMapper modelMapper;
	   
	@Override
	public ProfileDTO addCustomer(ProfileDTO customerDTO) {
		//StudentEntity studentEntity = studentDtoToStudentEntity(studentDTO);
		Profile customer = this.modelMapper.map(customerDTO, Profile.class);
		
		Profile savedCustomer = this.repository.save(customer);
		return this.modelMapper.map(savedCustomer, ProfileDTO.class);
		//return studentEntityToStudentDto(savedStudent);
	}

	@Override
	public List<ProfileDTO> getAllcustomer() {
		
		List<Profile> customerList = this.repository.findAll();
		List<ProfileDTO> customerDtoList = customerList.stream().map(customerObj->this.modelMapper.map(customerObj,ProfileDTO.class)).collect(Collectors.toList());
		return customerDtoList;
	}

	@Override
	public ProfileDTO getCustomerById(int customerId) {
		{
			if(repository.existsById(customerId)) {
				
			
				Profile customerObj=this.repository.findById(customerId).get();
			return this.modelMapper.map(customerObj, ProfileDTO.class);
		}
			else 
			{
				throw  new ResourceNotFoundException("Customer","Customer Id",customerId);
				
			}
	}


	}

	@Override
	public ProfileDTO updateCustomerById(ProfileDTO customerDTO, int customerId) {
		Profile customer=this.modelMapper.map(customerDTO,Profile.class);
		
		if(repository.existsById(customerId))
	{
			Profile updatedCustomer=this.repository.save(customer);
		return this.modelMapper.map(updatedCustomer, ProfileDTO.class);
	}
		else 
		{
			
			throw  new ResourceNotFoundException("Customer","Customer Id",customerId);
		}
	}

	@Override
	public void deleteCustomerById(int customerId) {
		if(repository.existsById(customerId))
		{
			repository.deleteById(customerId);
		
	    }
		else
		{
			throw  new ResourceNotFoundException("Customer","Customerr Id",customerId);
		}
		
	}

	}

	
	

	
	
	

