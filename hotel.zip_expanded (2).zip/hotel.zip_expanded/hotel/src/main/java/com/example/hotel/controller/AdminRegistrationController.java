package com.example.hotel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.hotel.entity.Admin;
import com.example.hotel.serviceImpl.AdminRegistrationService;

@CrossOrigin("*")
@RestController
public class AdminRegistrationController {
	@Autowired
	private  AdminRegistrationService service;
	@PostMapping("/registeradmin")
     public Admin registerAdmin(@RequestBody Admin admin) throws Exception {
		String tempEmailId = admin.getEmailId();
		if(tempEmailId != null && !"".equals(tempEmailId)) {
			Admin adminObj= service.fetchUserByEmailId(tempEmailId);
			if(adminObj != null)
			{
				throw new Exception("user with " + tempEmailId + "is already exists");
			}
		}
    	 Admin adminObj = null;
    	 adminObj = service.saveAdmin(admin);
    	 return adminObj ;
    	 }
	
	@PostMapping("/Adminlogin")
	public Admin loginAdmin(@RequestBody Admin admin) throws Exception {
		String tempEmailId=admin.getEmailId();
		String tempPass=admin.getPassword();
		Admin adminObj=null;
		if(tempEmailId != null && tempPass != null) {
			adminObj = service.fetchUserByEmailIdAndPassword(tempEmailId, tempPass);
		}
		if(adminObj==null) {
			throw new Exception("It is empty");
		}
		return adminObj;
	}
}
