package com.example.hotel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.example.hotel.entity.User1;
import com.example.hotel.serviceImpl.RegistrationService;

@RestController
public class RegistrationController {
	
	@Autowired
	private RegistrationService service;
	@CrossOrigin("http://localhost:4200")
	@PostMapping("/registeruser1")
     public User1 registerUser(@RequestBody User1 user1) throws Exception {
		String tempEmailId = user1.getEmailId();
		if(tempEmailId != null && !"".equals(tempEmailId)) {
			User1 user1Obj= service.fetchUserByEmailId(tempEmailId);
			if(user1Obj != null)
			{
				throw new Exception("user with " + tempEmailId + "is already exists");
			}
		}
    	 User1 user1Obj = null;
    	 user1Obj = service.saveUser1(user1);
    	 return user1Obj ;
    	 }
	@CrossOrigin("http://localhost:4200")
	@PostMapping("/login")
	public User1 loginUser1(@RequestBody User1 user1) throws Exception {
		String tempEmailId=user1.getEmailId();
		String tempPass=user1.getPassword();
		User1 user1Obj=null;
		if(tempEmailId != null && tempPass != null) {
			user1Obj = service.fetchUserByEmailIdAndPassword(tempEmailId, tempPass);
		}
		if(user1Obj == null) {
			throw new Exception("It is empty");
		}
		return user1Obj;
	}
}
