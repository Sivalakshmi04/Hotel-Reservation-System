package com.example.hotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;


import com.example.hotel.exception.APIResponse;
import com.example.hotel.payload.HotelDTO;

import com.example.hotel.service.HotelService;



@CrossOrigin("*")
@RestController
@RequestMapping("/hotel")
public class HotelController {

@Autowired
	private HotelService hotelService;

	
	@PostMapping("/save")
     public ResponseEntity<HotelDTO> saveHotel(@RequestBody HotelDTO hotelDTO)
     {
    	HotelDTO savedHotel=this.hotelService.addHotel(hotelDTO);
   	 System.out.println("********"+savedHotel);
    	 return new ResponseEntity<HotelDTO>(savedHotel,HttpStatus.CREATED);
     }
	@GetMapping("/")
	public ResponseEntity<List<HotelDTO>> getAllHotels()
	{
	List<HotelDTO> hotelList	= this.hotelService.getAllhotel(); 
	return new ResponseEntity<List<HotelDTO>>(hotelList,HttpStatus.OK);
	}
	@GetMapping("/{hotelId}")
	public ResponseEntity<HotelDTO> getHotelById(@PathVariable("hotelId") int hotelId)
	{
	HotelDTO hotelObj=this.hotelService.getHotelById(hotelId);
	return new ResponseEntity<HotelDTO>(hotelObj,HttpStatus.OK);
	}
	@PutMapping("/{hotelId}")
	public ResponseEntity<HotelDTO> updateHotel(@RequestBody HotelDTO  hotelDTO,@PathVariable("hotelId") int hotelId)
	{
	HotelDTO updatedHotel=this.hotelService.updateHotelById(hotelDTO,hotelId);
	return new ResponseEntity<HotelDTO>(updatedHotel,HttpStatus.OK);
	}
	@DeleteMapping("/{hotelId}")
	public ResponseEntity<APIResponse> deleteHotelById(@PathVariable("hotelId") int hotelId)
	{
	this.hotelService.deleteHotelById(hotelId);
	APIResponse obj=new APIResponse();
	obj.setMessage("hotel record is deleted successfully with Id "+hotelId);
	obj.setStatus(true);
	return new ResponseEntity<APIResponse>(obj,HttpStatus.OK);
	}

}
