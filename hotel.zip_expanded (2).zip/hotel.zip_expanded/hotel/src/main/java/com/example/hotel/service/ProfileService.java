package com.example.hotel.service;

import java.util.List;


import com.example.hotel.payload.ProfileDTO;

public interface ProfileService {
	//add all user
 public ProfileDTO addCustomer(ProfileDTO customerDTO);
 //get all user
 public List<ProfileDTO> getAllcustomer();
 //get user by id
 public ProfileDTO getCustomerById(int customerId);
 //update user by id
 public ProfileDTO updateCustomerById(ProfileDTO customerDTO,int customerId);
 //delete user by id
 public void deleteCustomerById(int customerId);
}

