package com.example.hotel.service;

import java.util.List;

import com.example.hotel.payload.HotelDTO;

public interface HotelService {

	//add all hotel
	 public HotelDTO addHotel(HotelDTO hotelDTO);
	 //get all hotel
	 public List<HotelDTO> getAllhotel();
	 //get hotel by id
	 public HotelDTO getHotelById(int hotelId);
	 //update hotel by id
	 public HotelDTO updateHotelById(HotelDTO hotelDTO,int hotelId);
	 //delete hotel by id
	 public void deleteHotelById(int hotelId);
}
