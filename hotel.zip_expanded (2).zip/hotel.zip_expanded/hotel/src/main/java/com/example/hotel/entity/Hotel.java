package com.example.hotel.entity;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Entity
//@Data
@Getter
@Setter
@ToString
@NoArgsConstructor
@Table(name="hotel")
public class Hotel {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int hotelId;
	
	@Column(nullable=false, length=30)
	private String hotelname;
	
	@Column(nullable=false, length=30)
	private String hoteltype;
	
//	@Column(nullable=false, length=30)
//	private String hotellocation;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "hId" ,  referencedColumnName = "hotelId")
	@JsonManagedReference
    private List<Employee> employees;
//	
//	
//	@OneToMany(cascade = CascadeType.ALL)
//	@JoinColumn(name = "rId" , referencedColumnName = "hotelId")
//	@JsonManagedReference
//    private List<Room> rooms;
	

}









//@OneToMany(mappedBy="hotel")
//private Set<Employee> employeee;



//@OneToMany(targetEntity = Employee.class,cascade = CascadeType.ALL)
//@JoinColumn(name= "work",referencedColumnName = "hotelId")
//private List<Employee> employees;
////	@OneToMany(cascade=CascadeType.ALL,mappedBy = "hotel")
////	Set<Work> workersList=new HashSet<>();
//@OneToMany(targetEntity = Room.class,cascade = CascadeType.ALL)
//@JoinColumn(name= "hotel_rooms",referencedColumnName = "hotelId")
//private List<Room> rooms;
