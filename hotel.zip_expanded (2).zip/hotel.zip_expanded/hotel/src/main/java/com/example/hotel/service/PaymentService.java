package com.example.hotel.service;

import java.util.List;


import com.example.hotel.payload.PaymentDTO;

public interface PaymentService {
	//add all hotel
		 public PaymentDTO addPayment(PaymentDTO paymentDTO);
		 //get all hotel
		 public List<PaymentDTO> getAllpayment();
		 //get hotel by id
		 public PaymentDTO getPaymentById(int paymentId);
		 //update hotel by id
		 public PaymentDTO updatePaymentById(PaymentDTO paymentDTO,int paymentId);
		 //delete hotel by id
		 public void deletePaymentById(int paymentId);
}
