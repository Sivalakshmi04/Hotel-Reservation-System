package com.example.hotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.hotel.exception.APIResponse;
import com.example.hotel.payload.EmployeeDTO;

import com.example.hotel.service.EmployeeService;

@CrossOrigin("*")
@RestController
@RequestMapping("/hotelEmployee")
public class EmployeeController {

@Autowired
	private EmployeeService employeeService;
	
	@PostMapping("/save")
     public ResponseEntity<EmployeeDTO> saveEmployee(@RequestBody EmployeeDTO employeeDTO)
     {
    	EmployeeDTO savedEmployee=this.employeeService.addEmployee(employeeDTO);
   	 System.out.println("********"+savedEmployee);
    	 return new ResponseEntity<EmployeeDTO>(savedEmployee,HttpStatus.CREATED);
     }
	@GetMapping("/")
	public ResponseEntity<List<EmployeeDTO>> getAllEmployees()
	{
	List<EmployeeDTO> employeeList	= this.employeeService.getAllemployee(); 
	return new ResponseEntity<List<EmployeeDTO>>(employeeList,HttpStatus.OK);
	}
	@GetMapping("/{employeeId}")
	public ResponseEntity<EmployeeDTO> getEmployeeById(@PathVariable("employeeId") int employeeId)
	{
		EmployeeDTO employeeObj=this.employeeService.getEmployeeById(employeeId);
	return new ResponseEntity<EmployeeDTO>(employeeObj,HttpStatus.OK);
	}
	@PutMapping("/{employeeId}")
	public ResponseEntity<EmployeeDTO> updateEmployee(@RequestBody EmployeeDTO  employeeDTO,@PathVariable("employeeId") int employeeId)
	{
		EmployeeDTO updatedEmployee=this.employeeService.updateEmployeeById(employeeDTO,employeeId);
	return new ResponseEntity<EmployeeDTO>(updatedEmployee,HttpStatus.OK);
	}
	@DeleteMapping("/{employeeId}")
	public ResponseEntity<APIResponse> deleteEmployeeById(@PathVariable("employeeId") int employeeId)
	{
	this.employeeService.deleteEmployeeById(employeeId);
	APIResponse obj=new APIResponse();
	obj.setMessage("Employee record is deleted successfully with Id "+employeeId);
	obj.setStatus(true);
	return new ResponseEntity<APIResponse>(obj,HttpStatus.OK);
	}
}
