package com.example.hotel.payload;




import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
@Data
//@Getter
//@Setter
@ToString
@NoArgsConstructor
public class ProfileDTO {
	
     private int customerId;
	 private int customerName;
	 private String contactNumber;
	 private String firstName;
	 private String lastName;
     private String emailId;
     private String address;
     private int age;
     private String dob;
     
	
	
}
