package com.example.hotel.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hotel.entity.Booking;

import com.example.hotel.exception.ResourceNotFoundException;
import com.example.hotel.payload.BookingDTO;
import com.example.hotel.repository.BookingRepository;
import com.example.hotel.service.BookingService;

@Service
public class BookingServiceImplementation implements BookingService{


 @Autowired 
		private BookingRepository repository;
	    
	    @Autowired 
	    private ModelMapper modelMapper;
	    
	@Override
	public BookingDTO addBooking(BookingDTO bookingDTO) {
		//StudentEntity studentEntity = studentDtoToStudentEntity(studentDTO);
				Booking booking = this.modelMapper.map(bookingDTO, Booking.class);
				
				Booking savedBooking = this.repository.save(booking);
				return this.modelMapper.map(savedBooking, BookingDTO.class);
				//return studentEntityToStudentDto(savedStudent);
	}

	@Override
	public List<BookingDTO> getAllbooking() {

		List<Booking> bookingList = this.repository.findAll();
		List<BookingDTO> bookingDtoList = bookingList.stream().map(bookingObj->this.modelMapper.map(bookingObj,BookingDTO.class)).collect(Collectors.toList());
		return bookingDtoList;
	}

	@Override
	public BookingDTO getBookingById(int bookingId) {
		{
			if(repository.existsById(bookingId)) {
				
			
		Booking bookingObj=this.repository.findById(bookingId).get();
			return this.modelMapper.map(bookingObj, BookingDTO.class);
		}
			else 
			{
				throw  new ResourceNotFoundException("Booking","Booking Id",bookingId);
				
			}
	}
	}

	@Override
	public BookingDTO updateBookingById(BookingDTO bookingDTO, int bookingId) {
		
Booking booking=this.modelMapper.map(bookingDTO,Booking.class);
		
		if(repository.existsById(bookingId))
	{
		Booking updatedBooking=this.repository.save(booking);
		return this.modelMapper.map(updatedBooking, BookingDTO.class);
	}
		else 
		{
			
			throw  new ResourceNotFoundException("Booking","Booking Id",bookingId);
		}
	}

	@Override
	public void deleteBookingById(int bookingId) {
		if(repository.existsById(bookingId))
		{
			repository.deleteById(bookingId);
		
	    }
		else
		{
			throw  new ResourceNotFoundException("booking","booking Id",bookingId);
		}
		
		
	}

}
