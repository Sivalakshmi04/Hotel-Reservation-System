package com.example.hotel.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.hotel.entity.Payment;
import com.example.hotel.exception.ResourceNotFoundException;

import com.example.hotel.payload.PaymentDTO;

import com.example.hotel.repository.PaymentRepository;
import com.example.hotel.service.PaymentService;


@Service
public class PaymentServiceImplementation implements PaymentService{
	 @Autowired 
		private PaymentRepository repository;
	    
	    @Autowired 
	    private ModelMapper modelMapper;
	    
	@Override
	public PaymentDTO addPayment(PaymentDTO paymentDTO) {
		
				Payment payment = this.modelMapper.map(paymentDTO,Payment.class);
				
				Payment savedPayment = this.repository.save(payment);
				return this.modelMapper.map(savedPayment, PaymentDTO.class);
			
	}
	@Override
	public List<PaymentDTO> getAllpayment() {

		List<Payment> paymentList = this.repository.findAll();
		List<PaymentDTO> paymentDtoList = paymentList.stream().map(paymentObj->this.modelMapper.map(paymentObj,PaymentDTO.class)).collect(Collectors.toList());
		return paymentDtoList;
	}
	@Override
	public PaymentDTO getPaymentById(int paymentId) {
		{
			if(repository.existsById(paymentId)) {
				
			
				Payment paymentObj=this.repository.findById(paymentId).get();
			return this.modelMapper.map(paymentObj, PaymentDTO.class);
		}
			else 
			{
				throw  new ResourceNotFoundException("Payment","Payment Id",paymentId);
				
			}
	}
	}

	@Override
	public PaymentDTO updatePaymentById(PaymentDTO paymentDTO, int paymentId) {
		Payment payment=this.modelMapper.map(paymentDTO,Payment.class);
		
		if(repository.existsById(paymentId))
	{
			Payment updatedPayment=this.repository.save(payment);
		return this.modelMapper.map(updatedPayment, PaymentDTO.class);
	}
		else 
		{
			
			throw  new ResourceNotFoundException("Payment","Payment Id",paymentId);
		}
	}

	@Override
	public void deletePaymentById(int paymentId) {
		if(repository.existsById(paymentId))
		{
			repository.deleteById(paymentId);
		
	    }
		else
		{
			throw  new ResourceNotFoundException("Payment","Payment Id",paymentId);
		}
		
		
	}


}

