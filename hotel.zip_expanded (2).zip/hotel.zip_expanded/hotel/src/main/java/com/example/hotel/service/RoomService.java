package com.example.hotel.service;

import java.util.List;

import com.example.hotel.payload.RoomDTO;


public interface RoomService {
	//add all room
	 public RoomDTO addRoom(RoomDTO roomDTO);
	//get all room
	 public List<RoomDTO> getAllroom();
	 //get room by id
	 public RoomDTO getRoomById(int roomId);
	 //update room by id
	 public RoomDTO updateRoomById(RoomDTO roomDTO,int roomId);
	 //delete room by id
	 public void deleteRoomById(int roomId);
}
