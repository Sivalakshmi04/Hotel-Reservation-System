package com.example.hotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.hotel.exception.APIResponse;
import com.example.hotel.payload.PaymentDTO;
import com.example.hotel.service.PaymentService;
@CrossOrigin("*")
@RestController
@RequestMapping("/payment")
public class PaymentController {
	@Autowired
	private PaymentService paymentService;
	@PostMapping("/save")
    public ResponseEntity<PaymentDTO> savePayment(@RequestBody PaymentDTO paymentDTO)
    {
   	PaymentDTO savedPayment=this.paymentService.addPayment(paymentDTO);
  	 System.out.println("********"+savedPayment);
   	 return new ResponseEntity<PaymentDTO>(savedPayment,HttpStatus.CREATED);
    }
	@GetMapping("/")
	public ResponseEntity<List<PaymentDTO>> getAllpayments()
	{
	List<PaymentDTO> paymentList	= this.paymentService.getAllpayment(); 
	return new ResponseEntity<List<PaymentDTO>>(paymentList,HttpStatus.OK);
	}
	@GetMapping("/{paymentId}")
	public ResponseEntity<PaymentDTO> getPaymentById(@PathVariable("paymentId") int paymentId)
	{
	PaymentDTO paymentObj=this.paymentService.getPaymentById(paymentId);
	return new ResponseEntity<PaymentDTO>(paymentObj,HttpStatus.OK);
	}
	@PutMapping("/{paymentId}")
	public ResponseEntity<PaymentDTO> updatePayment(@RequestBody PaymentDTO  paymentDTO,@PathVariable("paymentId") int paymentId)
	{
	PaymentDTO updatedPayment=this.paymentService.updatePaymentById(paymentDTO,paymentId);
	return new ResponseEntity<PaymentDTO>(updatedPayment,HttpStatus.OK);
	}
	@DeleteMapping("/{paymentId}")
	public ResponseEntity<APIResponse> deletePaymentById(@PathVariable("paymentId") int paymentId)
	{
	this.paymentService.deletePaymentById(paymentId);
	APIResponse obj=new APIResponse();
	obj.setMessage("payment record is deleted successfully with Id "+paymentId);
	obj.setStatus(true);
	return new ResponseEntity<APIResponse>(obj,HttpStatus.OK);
	}
}
