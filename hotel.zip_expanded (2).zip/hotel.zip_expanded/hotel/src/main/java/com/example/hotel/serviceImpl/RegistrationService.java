package com.example.hotel.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hotel.entity.User1;
import com.example.hotel.repository.RegistrationRepository;

@Service
public class RegistrationService {
	@Autowired
	private RegistrationRepository repo;
   public User1 saveUser1(User1 user1) {
	 return  repo.save(user1);
	    
   }
	
	public User1 fetchUserByEmailId(String email) {
		 return repo.findByEmailId(email);
	}
	public User1 fetchUserByEmailIdAndPassword(String email,String password) {
		 return repo.findByEmailIdAndPassword(email,password);
	}
}
