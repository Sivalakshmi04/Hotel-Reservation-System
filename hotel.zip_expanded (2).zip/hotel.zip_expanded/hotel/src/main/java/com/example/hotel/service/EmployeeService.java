package com.example.hotel.service;

import java.util.List;

import com.example.hotel.payload.EmployeeDTO;


public interface EmployeeService {

	//add all employee
	 public EmployeeDTO addEmployee(EmployeeDTO employeeDTO);
	 //get all employee
	 public List<EmployeeDTO> getAllemployee();
	 //get employee by id
	 public EmployeeDTO getEmployeeById(int employeeId);
	 //update employee by id
	 public EmployeeDTO updateEmployeeById(EmployeeDTO employeeDTO,int employeeId);
	 //delete employee by id
	 public void deleteEmployeeById(int employeeId);
}
