package com.example.hotel.payload;

import java.util.List;

import com.example.hotel.entity.Employee;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
//@Getter
//@Setter
@ToString
@NoArgsConstructor

public class HotelDTO {

	

	
	private int hotelId;
	
	
	private String hotelname;
	
	
	private String hoteltype;
	
//	private String hotellocation;
	 private List<Employee> employees;
	
}
