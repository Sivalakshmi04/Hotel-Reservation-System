package com.example.hotel.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hotel.entity.Admin;
import com.example.hotel.repository.AdminRegistrationRepository;

@Service
public class AdminRegistrationService {
	@Autowired
	private AdminRegistrationRepository repo;
   public Admin saveAdmin(Admin admin) {
	 return  repo.save(admin);
	    
   }
	
	public Admin fetchUserByEmailId(String email) {
		 return repo.findByEmailId(email);
	}
	public Admin fetchUserByEmailIdAndPassword(String email,String password) {
		 return repo.findByEmailIdAndPassword(email,password);
	}
}
