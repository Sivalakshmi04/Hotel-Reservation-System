package com.example.hotel.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Entity
//@Data
@Getter
@Setter
@ToString
@NoArgsConstructor
@Table(name="employee")
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int employeeId;
	
	@Column(nullable=false, length=30)
	private String empName;
	
	@Column(nullable=false, length=30)
	private String phoneNo;
	
	@Column(nullable=false, length=30)
	private String address;

//
//	private Integer hotel_id;
//	@ManyToOne(targetEntity=Hotel.class,fetch=FetchType.EAGER)
//	@JoinColumn(name="hotel_id",insertable=false,updatable=false)
//	private Hotel hotel;

}

//@ManyToOne
//@JoinColumn(name = "hotel_Id")
//private Hotel hotel;
//	@OneToMany(cascade=CascadeType.ALL,mappedBy = "employee")
//	Set<Work> workersList=new HashSet<>();
