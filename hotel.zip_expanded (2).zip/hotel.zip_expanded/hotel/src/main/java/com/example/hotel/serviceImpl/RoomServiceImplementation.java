package com.example.hotel.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hotel.entity.Room;

import com.example.hotel.exception.ResourceNotFoundException;
import com.example.hotel.payload.RoomDTO;

import com.example.hotel.repository.RoomRepository;
import com.example.hotel.service.RoomService;
@Service
public class RoomServiceImplementation implements RoomService {
	 @Autowired 
		private RoomRepository repository;
	    
	    @Autowired 
	    private ModelMapper modelMapper;


		@Override
		public RoomDTO addRoom(RoomDTO roomDTO) {
			
		Room room = this.modelMapper.map(roomDTO, Room.class);
			
			Room savedRoom = this.repository.save(room);
			return this.modelMapper.map(savedRoom, RoomDTO.class);
			
		}


		@Override
		public List<RoomDTO> getAllroom() {

			List<Room> roomList = this.repository.findAll();
			List<RoomDTO> roomDtoList = roomList.stream().map(roomObj->this.modelMapper.map(roomObj,RoomDTO.class)).collect(Collectors.toList());
			return roomDtoList;
		}


		@Override
		public RoomDTO getRoomById(int roomId) {

			if(repository.existsById(roomId)) {
				
			
		Room roomObj=this.repository.findById(roomId).get();
			return this.modelMapper.map(roomObj, RoomDTO.class);
		}
			else 
			{
				throw  new ResourceNotFoundException("Room","Room Id",roomId);
				
			}
	}

		


		@Override
		public RoomDTO updateRoomById(RoomDTO roomDTO, int roomId) {
			Room room=this.modelMapper.map(roomDTO,Room.class);
			
			if(repository.existsById(roomId))
		{
			Room updatedRoom=this.repository.save(room);
			return this.modelMapper.map(updatedRoom, RoomDTO.class);
		}
			else 
			{
				
				throw  new ResourceNotFoundException("Room","Room Id",roomId);
			}
		}


		@Override
		public void deleteRoomById(int roomId) {
			if(repository.existsById(roomId))
			{
				repository.deleteById(roomId);
			
		    }
			else
			{
				throw  new ResourceNotFoundException("Room","Room Id",roomId);
			}
			
			
		}
		
}
