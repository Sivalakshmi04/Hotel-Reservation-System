package com.example.hotel.payload;



import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
//@Getter
//@Setter
@ToString
@NoArgsConstructor
public class BookingDTO {
private int bookingId;
	
	
	private String customerName;
	
	
	private String phoneNo;
	
	
	private String address;
	
	private String checkIn;
	
	private String checkOut;
	
	private long totalRoom;
	
	private long totalDay;
}
