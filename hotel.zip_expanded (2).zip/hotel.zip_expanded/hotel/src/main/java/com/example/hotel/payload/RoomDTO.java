package com.example.hotel.payload;


import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
@Data
//@Getter
//@Setter
@ToString
@NoArgsConstructor
public class RoomDTO {

	
	private int roomId;
	
	
	private String roomtype;
	
	
	private boolean roomStatus;
	

	private long roomPrice;
}
