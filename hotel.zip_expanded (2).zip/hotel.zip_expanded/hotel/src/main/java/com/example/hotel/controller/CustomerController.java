//package com.example.hotel.controller;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.example.hotel.exception.APIResponse;
//import com.example.hotel.payload.CustomerDTO;
//import com.example.hotel.service.CustomerService;
//@CrossOrigin("*")
//@RestController
//@RequestMapping("/customer")
//public class CustomerController {
//
//
//@Autowired
//	private CustomerService customerService;
//	
//	@PostMapping("/save")
//     public ResponseEntity<CustomerDTO> saveCustomer(@RequestBody CustomerDTO customerDTO)
//     {
//    	CustomerDTO savedCustomer=this.customerService.addCustomer(customerDTO);
//   	 System.out.println("********"+savedCustomer);
//    	 return new ResponseEntity<CustomerDTO>(savedCustomer,HttpStatus.CREATED);
//     }
//@GetMapping("/")
//public ResponseEntity<List<CustomerDTO>> getAllCustomers()
//{
//List<CustomerDTO> customerList	= this.customerService.getAllcustomer(); 
//return new ResponseEntity<List<CustomerDTO>>(customerList,HttpStatus.OK);
//}
//@GetMapping("/{customerId}")
//public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable("customerId") int customerId)
//{
//CustomerDTO customerObj=this.customerService.getCustomerById(customerId);
//return new ResponseEntity<CustomerDTO>(customerObj,HttpStatus.OK);
//}
//@PutMapping("/{customerId}")
//public ResponseEntity<CustomerDTO> updateUser(@RequestBody CustomerDTO  customerDTO,@PathVariable("customerId") int customerId)
//{
//CustomerDTO updatedCustomer=this.customerService.updateCustomerById(customerDTO,customerId);
//return new ResponseEntity<CustomerDTO>(updatedCustomer,HttpStatus.OK);
//}
//@DeleteMapping("/{customerId}")
//public ResponseEntity<APIResponse> deleteCustomerById(@PathVariable("customerId") int customerId)
//{
//this.customerService.deleteCustomerById(customerId);
//APIResponse obj=new APIResponse();
//obj.setMessage("customer record is deleted successfully with Id "+customerId);
//obj.setStatus(true);
//return new ResponseEntity<APIResponse>(obj,HttpStatus.OK);
//}
//}