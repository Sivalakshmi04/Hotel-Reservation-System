package com.example.hotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.hotel.exception.APIResponse;
import com.example.hotel.payload.BookingDTO;
import com.example.hotel.service.BookingService;

@CrossOrigin("*")
@RestController
@RequestMapping("/booking")
public class BookingController {
@Autowired
	private BookingService bookingService;

	
	@PostMapping("/save")
     public ResponseEntity<BookingDTO> saveBooking(@RequestBody BookingDTO bookingDTO)
     {
    	BookingDTO savedBooking=this.bookingService.addBooking(bookingDTO);
   	 System.out.println("********"+savedBooking);
    	 return new ResponseEntity<BookingDTO>(savedBooking,HttpStatus.CREATED);
     }
	@GetMapping("/")
	public ResponseEntity<List<BookingDTO>> getAllBookings()
	{
	List<BookingDTO> bookingList	= this.bookingService.getAllbooking(); 
	return new ResponseEntity<List<BookingDTO>>(bookingList,HttpStatus.OK);
	}
	@GetMapping("/{bookingId}")
	public ResponseEntity<BookingDTO> getBookingById(@PathVariable("bookingId") int bookingId)
	{
	BookingDTO bookingObj=this.bookingService.getBookingById(bookingId);
	return new ResponseEntity<BookingDTO>(bookingObj,HttpStatus.OK);
	}
	@PutMapping("/{bookingId}")
	public ResponseEntity<BookingDTO> updateBooking(@RequestBody BookingDTO  bookingDTO,@PathVariable("bookingId") int bookingId)
	{
	BookingDTO updatedBooking=this.bookingService.updateBookingById(bookingDTO,bookingId);
	return new ResponseEntity<BookingDTO>(updatedBooking,HttpStatus.OK);
	}
	@DeleteMapping("/{bookingId}")
	public ResponseEntity<APIResponse> deleteBookingById(@PathVariable("bookingId") int bookingId)
	{
	this.bookingService.deleteBookingById(bookingId);
	APIResponse obj=new APIResponse();
	obj.setMessage("booking record is deleted successfully with Id "+bookingId);
	obj.setStatus(true);
	return new ResponseEntity<APIResponse>(obj,HttpStatus.OK);
	}

}
