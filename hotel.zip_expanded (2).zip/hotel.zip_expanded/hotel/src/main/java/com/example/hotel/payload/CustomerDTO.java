//package com.example.hotel.payload;
//
//
//
//
//import lombok.Data;
//import lombok.NoArgsConstructor;
//import lombok.ToString;
//@Data
////@Getter
////@Setter
//@ToString
//@NoArgsConstructor
//public class CustomerDTO {
//	
//     private int customerId;
//	 private String customerName;
//	 private String contactNumber;
//     private String emailId;
//	
//	
//}
