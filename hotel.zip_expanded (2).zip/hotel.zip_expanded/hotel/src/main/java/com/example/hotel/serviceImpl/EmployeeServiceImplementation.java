package com.example.hotel.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hotel.entity.Employee;

import com.example.hotel.exception.ResourceNotFoundException;
import com.example.hotel.payload.EmployeeDTO;

import com.example.hotel.repository.EmployeeRepository;
import com.example.hotel.service.EmployeeService;



@Service
public class EmployeeServiceImplementation implements EmployeeService{

	 @Autowired 
		private EmployeeRepository repository;
	    
	    @Autowired 
	    private ModelMapper modelMapper;

		@Override
		public EmployeeDTO addEmployee(EmployeeDTO employeeDTO) {
          
			Employee employee= this.modelMapper.map(employeeDTO, Employee.class);
			
			Employee savedEmployee = this.repository.save(employee);
			return this.modelMapper.map(savedEmployee, EmployeeDTO.class);
		}

		@Override
		public List<EmployeeDTO> getAllemployee() {
			List<Employee> employeeList = this.repository.findAll();
			List<EmployeeDTO> employeeDtoList = employeeList.stream().map(employeeObj->this.modelMapper.map(employeeObj,EmployeeDTO.class)).collect(Collectors.toList());
			return employeeDtoList;
		}

		@Override
		public EmployeeDTO getEmployeeById(int employeeId) {
			if(repository.existsById(employeeId)) {
				
				
				Employee employeeObj=this.repository.findById(employeeId).get();
					return this.modelMapper.map(employeeObj, EmployeeDTO.class);
				}
					else 
					{
						throw  new ResourceNotFoundException("Employee","Employee Id",employeeId);
						
					}
		}

		@Override
		public EmployeeDTO updateEmployeeById(EmployeeDTO employeeDTO, int employeeId) {
			Employee employee=this.modelMapper.map(employeeDTO,Employee.class);
			
			if(repository.existsById(employeeId))
		{
				Employee updatedEmployee=this.repository.save(employee);
			return this.modelMapper.map(updatedEmployee, EmployeeDTO.class);
		}
			else 
			{
				
				throw  new ResourceNotFoundException("Employee","Employee Id",employeeId);
			}
		}

		@Override
		public void deleteEmployeeById(int employeeId) {
			if(repository.existsById(employeeId))
			{
				repository.deleteById(employeeId);
			
		    }
			else
			{
				throw  new ResourceNotFoundException("Employee","Employee Id",employeeId);
			}
			
			
		}


}
