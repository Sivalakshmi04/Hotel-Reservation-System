package com.example.hotel.payload;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
//@Getter
//@Setter
@ToString
@NoArgsConstructor

public class PaymentDTO {
	
	private int paymentId;
	
    private String payment_date;

    private String paymentMethod;

    private long paymentAmount;
}
