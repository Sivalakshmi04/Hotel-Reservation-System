package com.example.hotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.hotel.exception.APIResponse;
import com.example.hotel.payload.RoomDTO;

import com.example.hotel.service.RoomService;

@CrossOrigin("*")
@RestController
@RequestMapping("/room")
public class RoomController {

	@Autowired
	private RoomService roomService;
	
	@PostMapping("/save")
     public ResponseEntity<RoomDTO> saveUser(@RequestBody RoomDTO roomDTO)
     {
    	RoomDTO savedUser=this.roomService.addRoom(roomDTO);
   	 System.out.println("********"+savedUser);
    	 return new ResponseEntity<RoomDTO>(savedUser,HttpStatus.CREATED);
     }
	@GetMapping("/")
	public ResponseEntity<List<RoomDTO>> getAllRooms()
	{
	List<RoomDTO> roomList	= this.roomService.getAllroom(); 
	return new ResponseEntity<List<RoomDTO>>(roomList,HttpStatus.OK);
	}
	@GetMapping("/{roomId}")
	public ResponseEntity<RoomDTO> getRoomById(@PathVariable("roomId") int roomId)
	{
	RoomDTO roomObj=this.roomService.getRoomById(roomId);
	return new ResponseEntity<RoomDTO>(roomObj,HttpStatus.OK);
	}
	@PutMapping("/{roomId}")
	public ResponseEntity<RoomDTO> updateRoom(@RequestBody RoomDTO roomDTO,@PathVariable("roomId") int roomId)
	{
	RoomDTO updatedRoom=this.roomService.updateRoomById(roomDTO,roomId);
	return new ResponseEntity<RoomDTO>(updatedRoom,HttpStatus.OK);
	}
	@DeleteMapping("/{roomId}")
	public ResponseEntity<APIResponse> deleteRoomById(@PathVariable("roomId") int roomId)
	{
	this.roomService.deleteRoomById(roomId);
	APIResponse obj=new APIResponse();
	obj.setMessage("room record is deleted successfully with Id "+roomId);
	obj.setStatus(true);
	return new ResponseEntity<APIResponse>(obj,HttpStatus.OK);
	}
}
