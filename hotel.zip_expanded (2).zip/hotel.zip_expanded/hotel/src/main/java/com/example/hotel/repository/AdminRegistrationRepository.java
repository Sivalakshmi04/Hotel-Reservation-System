package com.example.hotel.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.hotel.entity.Admin;

public interface AdminRegistrationRepository extends JpaRepository<Admin, Integer> {
	 public Admin findByEmailId(String emailId);
	 public Admin findByEmailIdAndPassword(String emailId,String password);
}
