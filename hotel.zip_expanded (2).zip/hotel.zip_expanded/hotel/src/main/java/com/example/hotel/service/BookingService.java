package com.example.hotel.service;

import java.util.List;

import com.example.hotel.payload.BookingDTO;

public interface BookingService {
	//add all hotel
		 public BookingDTO addBooking(BookingDTO bookingDTO);
		 //get all hotel
		 public List<BookingDTO> getAllbooking();
		 //get hotel by id
		 public BookingDTO getBookingById(int bookingId);
		 //update hotel by id
		 public BookingDTO updateBookingById(BookingDTO bookingDTO,int bookingId);
		 //delete hotel by id
		 public void deleteBookingById(int bookingId);
}
